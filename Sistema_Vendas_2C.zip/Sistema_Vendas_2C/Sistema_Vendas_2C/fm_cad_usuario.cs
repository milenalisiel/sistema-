﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sistema_Vendas_2C
{
    public partial class fm_cad_usuario : Form
    {
        public fm_cad_usuario()
        {
            InitializeComponent();
        }
    }
}
