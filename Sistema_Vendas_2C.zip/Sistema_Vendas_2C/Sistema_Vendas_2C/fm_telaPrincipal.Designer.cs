﻿namespace Sistema_Vendas_2C
{
    partial class fm_telaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fm_telaPrincipal));
            this.tab_Principal = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tb_senhaCadastrarUsuario = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_nomeCadastrarUsuario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_cadastrarUsuario = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tbNomeApagarUsuário = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.bt_fechar = new System.Windows.Forms.Button();
            this.tb_NovaSenhaEditarUsuário = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_NomeEditarUsuário = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_EditarUsuário = new System.Windows.Forms.Button();
            this.tab_Principal.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab_Principal
            // 
            this.tab_Principal.Controls.Add(this.tabPage1);
            this.tab_Principal.Controls.Add(this.tabPage2);
            this.tab_Principal.Controls.Add(this.tabPage3);
            this.tab_Principal.Controls.Add(this.tabPage4);
            this.tab_Principal.Location = new System.Drawing.Point(9, 43);
            this.tab_Principal.Name = "tab_Principal";
            this.tab_Principal.SelectedIndex = 0;
            this.tab_Principal.Size = new System.Drawing.Size(758, 381);
            this.tab_Principal.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.tabControl1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(750, 355);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "USUÁRIO";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(6, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(741, 340);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tb_senhaCadastrarUsuario);
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.tb_nomeCadastrarUsuario);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.bt_cadastrarUsuario);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(733, 314);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Cadastrar";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tb_senhaCadastrarUsuario
            // 
            this.tb_senhaCadastrarUsuario.Location = new System.Drawing.Point(34, 108);
            this.tb_senhaCadastrarUsuario.Name = "tb_senhaCadastrarUsuario";
            this.tb_senhaCadastrarUsuario.Size = new System.Drawing.Size(152, 20);
            this.tb_senhaCadastrarUsuario.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Senha";
            // 
            // tb_nomeCadastrarUsuario
            // 
            this.tb_nomeCadastrarUsuario.Location = new System.Drawing.Point(34, 35);
            this.tb_nomeCadastrarUsuario.Name = "tb_nomeCadastrarUsuario";
            this.tb_nomeCadastrarUsuario.Size = new System.Drawing.Size(152, 20);
            this.tb_nomeCadastrarUsuario.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nome";
            // 
            // bt_cadastrarUsuario
            // 
            this.bt_cadastrarUsuario.Location = new System.Drawing.Point(34, 188);
            this.bt_cadastrarUsuario.Name = "bt_cadastrarUsuario";
            this.bt_cadastrarUsuario.Size = new System.Drawing.Size(152, 23);
            this.bt_cadastrarUsuario.TabIndex = 0;
            this.bt_cadastrarUsuario.Text = "Cadastrar";
            this.bt_cadastrarUsuario.UseVisualStyleBackColor = true;
            this.bt_cadastrarUsuario.Click += new System.EventHandler(this.bt_cadastrarUsuario_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tbNomeApagarUsuário);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.button3);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(733, 314);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Apagar";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tbNomeApagarUsuário
            // 
            this.tbNomeApagarUsuário.Location = new System.Drawing.Point(34, 35);
            this.tbNomeApagarUsuário.Name = "tbNomeApagarUsuário";
            this.tbNomeApagarUsuário.Size = new System.Drawing.Size(152, 20);
            this.tbNomeApagarUsuário.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nome";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(34, 188);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(152, 23);
            this.button3.TabIndex = 5;
            this.button3.Text = "Apagar Usuário";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tb_NovaSenhaEditarUsuário);
            this.tabPage7.Controls.Add(this.label5);
            this.tabPage7.Controls.Add(this.tb_NomeEditarUsuário);
            this.tabPage7.Controls.Add(this.label6);
            this.tabPage7.Controls.Add(this.bt_EditarUsuário);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(733, 314);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Editar";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox4);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(750, 355);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ESTOQUE";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(34, 40);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(152, 20);
            this.textBox4.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Nome";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(34, 193);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(152, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Apagar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(750, 355);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "VENDAS";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(750, 355);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "RELATÓRIOS";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // bt_fechar
            // 
            this.bt_fechar.Location = new System.Drawing.Point(692, 12);
            this.bt_fechar.Name = "bt_fechar";
            this.bt_fechar.Size = new System.Drawing.Size(75, 23);
            this.bt_fechar.TabIndex = 3;
            this.bt_fechar.Text = "FECHAR";
            this.bt_fechar.UseVisualStyleBackColor = true;
            this.bt_fechar.Click += new System.EventHandler(this.bt_fechar_Click);
            // 
            // tb_NovaSenhaEditarUsuário
            // 
            this.tb_NovaSenhaEditarUsuário.Location = new System.Drawing.Point(34, 108);
            this.tb_NovaSenhaEditarUsuário.Name = "tb_NovaSenhaEditarUsuário";
            this.tb_NovaSenhaEditarUsuário.Size = new System.Drawing.Size(152, 20);
            this.tb_NovaSenhaEditarUsuário.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nova Senha";
            // 
            // tb_NomeEditarUsuário
            // 
            this.tb_NomeEditarUsuário.Location = new System.Drawing.Point(34, 35);
            this.tb_NomeEditarUsuário.Name = "tb_NomeEditarUsuário";
            this.tb_NomeEditarUsuário.Size = new System.Drawing.Size(152, 20);
            this.tb_NomeEditarUsuário.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Nome";
            // 
            // bt_EditarUsuário
            // 
            this.bt_EditarUsuário.Location = new System.Drawing.Point(34, 188);
            this.bt_EditarUsuário.Name = "bt_EditarUsuário";
            this.bt_EditarUsuário.Size = new System.Drawing.Size(152, 23);
            this.bt_EditarUsuário.TabIndex = 5;
            this.bt_EditarUsuário.Text = "Editar";
            this.bt_EditarUsuário.UseVisualStyleBackColor = true;
            this.bt_EditarUsuário.Click += new System.EventHandler(this.bt_EditarUsuário_Click);
            // 
            // fm_telaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(779, 436);
            this.Controls.Add(this.bt_fechar);
            this.Controls.Add(this.tab_Principal);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "fm_telaPrincipal";
            this.Text = "ACB Sistemas";
            this.tab_Principal.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tab_Principal;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox tb_senhaCadastrarUsuario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_nomeCadastrarUsuario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_cadastrarUsuario;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox tbNomeApagarUsuário;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button bt_fechar;
        private System.Windows.Forms.TextBox tb_NovaSenhaEditarUsuário;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_NomeEditarUsuário;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bt_EditarUsuário;
    }
}