﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sistema_Vendas_2C
{
    class ClVariaveisGlobais
    {
        public static String versãoDoSistema = "Vendas - V 0.1";
    }
}
